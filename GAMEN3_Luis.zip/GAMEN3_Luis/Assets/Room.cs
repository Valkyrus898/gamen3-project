using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room : MonoBehaviour
{
    public GameObject ExitNorth, ExitSouth, ExitEast, ExitWest;
    public bool ExitNorthBool, ExitSouthBool, ExitEastBool, ExitWestBool;

    public void InitExits(bool N, bool E, bool S, bool W)
    {
        ExitNorthBool = N;
        ExitSouthBool = S;
        ExitEastBool = E;
        ExitWestBool = W; 
        ExitNorth.SetActive(N);
        ExitSouth.SetActive(S);
        ExitEast.SetActive(E);
        ExitWest.SetActive(W);
    }
}
