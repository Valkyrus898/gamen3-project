using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class RoomSpawner : MonoBehaviour
{
    GameObject[,] rooms = new GameObject[4, 4];
    GameObject room;
    public bool N, E, W, S;
    public Transform Prefab;

    // Start is called before the first frame update
    void Start()
    {
        create();
    }

    void create()
    {
        for (int i = 0; i< 4; i++)
        {
            for (int j = 0; j< 4; j++)
            {
                //Creates the room at a certain position
                Instantiate(Prefab, new Vector3(585 + i* 10F, 0, -58 + j* 10F), Quaternion.identity);

                //Makes sure that the rooms in the middle are not completely closed
                if (i == 1 && j == 1 || i == 2 && j == 1 || i == 1 && j == 2 || i == 2 && j == 2)
                {
                    while (N == true && N == E && N == S && N == W)
                    {
                        S = Random.value > 0.5;
                        E = Random.value > 0.5;
                    }
                }

                //All doors on the north side are closed
                if (i == 0){
                    N = true;
                    S = Random.value > 0.5;
                }

                //All doors on the south are closed
                if (i == 3){
                    N = Random.value > 0.5;
                    S = true;
                }

                //All doors on the west are closed
                if (j == 0){
                    W = true;
                    E = Random.value > 0.5;
                }

                //All doors on the east are closed
                if (j == 3){
                    W = Random.value > 0.5;
                    E = true;
                }

                // For the first room the north side door is open
                if (i == 0 && j == 0){
                    N = false;
                    while (S == true && E == true)
                    {
                        S = Random.value > 0.5;
                        E = Random.value > 0.5;
                    }
                }
                // Creates an exit for the last room
                if (i == 3 && j == 3){
                    S = false;
                }

                Prefab.GetComponent<Room>().InitExits(N, E, S, W);
            }
        }
    }
}